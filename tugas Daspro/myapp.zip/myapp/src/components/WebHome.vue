<template>
    <div style="...">
        Home components
    </div>
</template>