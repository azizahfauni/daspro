﻿using System;

namespace Tiket_Bioskop
{
    class Program
    {
        static void Main(string[] args)
        {
            string Harga;
            Console.Write("Nama        : ");
            string Nama = Console.ReadLine();
            Console.Write("Tahun Lahir :");
            int tahunLahir = Convert.ToInt32(Console.ReadLine());
            
            int Usia = 2022 - tahunLahir;

            if(Usia < 10 || Usia > 60){
                Harga = "Rp. 10.000,00";
            }else{
                Harga = "Rp. 25.000,00";
            }
            Console.WriteLine("|*******************************|");
            Console.WriteLine("|         -- Studio 1 --        |");
            Console.WriteLine("|*******************************|");
            Console.WriteLine(String.Format("| {0,-12}{1,-12 }      |", "Nama  : ", Nama));
            Console.WriteLine(String.Format("| {0,-12}{1,-12}     |", "Harga : ", Harga));
            Console.WriteLine("|-------------------------------|");



        }
    }
}
