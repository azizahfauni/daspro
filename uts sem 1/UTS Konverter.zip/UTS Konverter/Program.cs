﻿using System;

namespace UTS_Konverter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Rate USD ke RP :");
            double HargaUSD = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Jumlah USD :");
            double JumlahUSD = Convert.ToDouble(Console.ReadLine());

            double Hasil = HargaUSD * JumlahUSD;
            Console.WriteLine("Hasil Konversi : "+Hasil);

        }
    }
}
