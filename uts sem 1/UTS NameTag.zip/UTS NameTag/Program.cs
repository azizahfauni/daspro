﻿using System;

namespace UTS_NameTag
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Nama        : ");
            string nama = Console.ReadLine();
            Console.WriteLine("Nim         : ");
            string nim = Console.ReadLine();
            Console.WriteLine("Konsentrasi : ");
            string konsentrasi = Console.ReadLine();
            mahasiswaBaru mhs = new mahasiswaBaru(nama, nim, konsentrasi);
            mhs.printNameTag();
        }
    }
    class mahasiswaBaru
    {
        string nama;
        string nim;
        string konsentrasi;

        public mahasiswaBaru(string Nama, string Nim, string Konsentrasi){
            nama = Nama;
            nim = Nim ;
            konsentrasi = Konsentrasi;
        }
        public void printNameTag(){
            Console.WriteLine("|*********************************|");
            Console.WriteLine("|Nama : {0,26}|",nama);
            Console.WriteLine("|       {0,26}|",nim);
            Console.WriteLine("|---------------------------------|");
            Console.WriteLine("|       {0,26}|",konsentrasi);
            Console.WriteLine("|*********************************|");
        }
    }
}
