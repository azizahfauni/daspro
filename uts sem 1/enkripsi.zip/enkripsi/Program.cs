﻿using System;

namespace enkripsi
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Selamat datang di program enskripsi...");
            Console.WriteLine("tekan enter");
            Console.ReadLine();

            Start :
            Console.WriteLine("-----Enkripsi teks-----");
            Console.WriteLine();
            Console.WriteLine("Teks : ");
            string Teks = Console.ReadLine();
            string[]Simbol = {"`", "~", "!", "@", "#", "$","%", "^","&", "*", "(", ")", "-","_", "=", "+","{", "}", "[","]", "\\" ,"|",
             ";" , ":", "'" , "'", "," , "<" , ".", ">" , "/" , "?" };
            
            foreach (string s in Simbol)
            {
                if(Teks.Contains(s))
                {
                    Console.WriteLine("tidak dapat mengimput simbol");
                    Console.ReadLine();
                    Console.Clear();
                    goto Start;
                }              
            }

            string[] Angka = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9"};
            foreach (string a in Angka)
            {
                if(Teks.Contains(a))
                {
                    Console.WriteLine("tidak dapat mengimput angka");
                    Console.ReadLine();
                    Console.Clear();
                    goto Start;

                }
            }
            if(string.IsNullOrEmpty(Teks))
            {
                Console.WriteLine("tidak dapat mendeteksi inputan");
                Console.ReadLine();
                Console.Clear();
                goto Start;
            }else if(string.IsNullOrWhiteSpace(Teks)){
                Console.WriteLine("tidak dapat mendeteksi inputan");
                Console.ReadLine();
                Console.Clear();
                goto Start;
            }

            Console.WriteLine();
            string Hasil = Enkripsi(Teks);
            Console.WriteLine("Hasil Enkripsi : "+Hasil);
            Console.WriteLine("-----------------------------------------------");
        }

        private static string Enkripsi(string Huruf)
        {
            char PecahKata;
            string Hasil = null;
            for (int i = 0; i < Huruf.Length; i++)
            {
                PecahKata = Huruf[i];
                switch(PecahKata)
                {
                    case 'a' :
                    PecahKata = 'd';
                    break;

                    case 'b' :
                    PecahKata = 'e';
                    break;

                    case 'c' :
                    PecahKata = 'f';
                    break;

                    case 'd' :
                    PecahKata = 'g';
                    break;

                    case 'e' :
                    PecahKata = 'h';
                    break;

                    case 'f' :
                    PecahKata = 'i';
                    break;

                    case 'g' :
                    PecahKata = 'j';
                    break;

                    case 'h' :
                    PecahKata = 'k';
                    break;

                    case 'i' :
                    PecahKata = 'l';
                    break;

                    case 'j' :
                    PecahKata = 'm';
                    break;

                    case 'k' :
                    PecahKata = 'n';
                    break;

                    case 'l' :
                    PecahKata = 'o';
                    break;

                    case 'm' :
                    PecahKata = 'p';
                    break;

                    case 'n' :
                    PecahKata = 'q';
                    break;

                    case 'o' :
                    PecahKata = 'r';
                    break;

                    case 'p' :
                    PecahKata = 's';
                    break;

                    case 'q' :
                    PecahKata = 't';
                    break;

                    case 'r' :
                    PecahKata = 'u';
                    break;

                    case 's' :
                    PecahKata = 'v';
                    break;

                    case 't' :
                    PecahKata = 'w';
                    break;

                    case 'u' :
                    PecahKata = 'x';
                    break;

                    case 'v' :
                    PecahKata = 'y';
                    break;

                    case 'w' :
                    PecahKata = 'z';
                    break;

                    case 'x' :
                    PecahKata = 'a';
                    break;

                    case 'y' :
                    PecahKata = 'b';
                    break;

                    case 'z' :
                    PecahKata = 'c';
                    break;

                    case 'A' :
                    PecahKata = 'D';
                    break;

                    case 'B' :
                    PecahKata = 'E';
                    break;

                    case 'C' :
                    PecahKata = 'F';
                    break;

                    case 'D' :
                    PecahKata = 'G';
                    break;

                    case 'E' :
                    PecahKata = 'H';
                    break;

                    case 'F' :
                    PecahKata = 'I';
                    break;

                    case 'G' :
                    PecahKata = 'J';
                    break;

                    case 'H' :
                    PecahKata = 'K';
                    break;

                    case 'I' :
                    PecahKata = 'L';
                    break;

                    case 'J' :
                    PecahKata = 'M';
                    break;

                    case 'K' :
                    PecahKata = 'N';
                    break;

                    case 'L' :
                    PecahKata = 'O';
                    break;

                    case 'M' :
                    PecahKata = 'P';
                    break;

                    case 'N' :
                    PecahKata = 'Q';
                    break;

                    case 'O' :
                    PecahKata = 'R';
                    break;

                    case 'P' :
                    PecahKata = 'S';
                    break;

                    case 'Q' :
                    PecahKata = 'T';
                    break;

                    case 'R' :
                    PecahKata = 'U';
                    break;

                    case 'S' :
                    PecahKata = 'V';
                    break;

                    case 'T' :
                    PecahKata = 'W';
                    break;

                    case 'U' :
                    PecahKata = 'X';
                    break;

                    case 'V' :
                    PecahKata = 'Y';
                    break;

                    case 'W' :
                    PecahKata = 'Z';
                    break;

                    case 'X' :
                    PecahKata = 'A';
                    break;

                    case 'Y' :
                    PecahKata = 'B';
                    break;

                    case 'Z' :
                    PecahKata = 'C';
                    break;
                }
                Hasil = Hasil + PecahKata;
            }
            return Hasil;
        }
    }
}

    
